import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ionicons/ionicons.dart';
import 'package:widget_marquee/widget_marquee.dart';

import '/ui/player/components/animated_play_button.dart';
import '../player_controller.dart';

class PlayerControlWidget extends StatelessWidget {
  const PlayerControlWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final PlayerController playerController = Get.find<PlayerController>();
    final theme = Theme.of(context);

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(height: 16),

        // =================== ALBUM ART WITH PROGRESS BAR ===================
        GetX<PlayerController>(
          builder: (controller) {
            final song = controller.currentSong.value;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  // Album Art
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: AspectRatio(
                      aspectRatio: 1,
                      child: song?.artUri != null
                          ? Image.network(
                              song!.artUri.toString(),
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: Colors.black12,
                                child: const Icon(Icons.music_note, size: 60),
                              ),
                            )
                          : Container(
                              color: Colors.black12,
                              child: const Icon(Icons.music_note, size: 60),
                            ),
                    ),
                  ),

                  // Progress Bar overlay (on top of album art)
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: GetX<PlayerController>(
                      builder: (c) {
                        return ProgressBar(
                          barHeight: 4,
                          thumbRadius: 6,
                          baseBarColor: Colors.white.withOpacity(0.25),
                          progressBarColor: Colors.white,
                          bufferedBarColor: Colors.white.withOpacity(0.5),
                          thumbColor: Colors.white,
                          timeLabelLocation: TimeLabelLocation.none,
                          progress: c.progressBarStatus.value.current,
                          buffered: c.progressBarStatus.value.buffered,
                          total: c.progressBarStatus.value.total,
                          onSeek: c.seek,
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        ),

        const SizedBox(height: 24),

        // =================== TITLE & ARTIST ===================
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ShaderMask(
            shaderCallback: (rect) => const LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [Colors.white, Colors.white, Colors.transparent],
            ).createShader(rect),
            blendMode: BlendMode.dstIn,
            child: Column(
              children: [
                Obx(() {
                  final playerController = Get.find<PlayerController>();
                  final song = playerController.currentSong.value;
                  return Marquee(
                    delay: const Duration(milliseconds: 300),
                    duration: const Duration(seconds: 10),
                    id: "${song}_title",
                    child: Text(
                      song != null ? song.title : "Unknown Song",
                      textAlign: TextAlign.center,
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  );
                }),
                const SizedBox(height: 6),
                Obx(() {
                  final playerController = Get.find<PlayerController>();
                  final song = playerController.currentSong.value;
                  return Marquee(
                    delay: const Duration(milliseconds: 300),
                    duration: const Duration(seconds: 10),
                    id: "${song}_artist",
                    child: Text(
                      song != null ? song.artist ?? "Unknown Artist" : "",
                      textAlign: TextAlign.center,
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: Colors.white.withOpacity(0.7),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        ),

        const SizedBox(height: 30),

        // =================== CONTROLS ===================
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            // Favorite button
            IconButton(
              onPressed: playerController.toggleFavourite,
              icon: Obx(() => Icon(
                    playerController.isCurrentSongFav.isFalse
                        ? Icons.favorite_border
                        : Icons.favorite,
                    color: theme.textTheme.titleMedium!.color,
                  )),
            ),

            // Previous
            IconButton(
              onPressed: playerController.prev,
              icon: Icon(
                Icons.skip_previous_rounded,
                color: theme.textTheme.titleMedium!.color,
                size: 32,
              ),
            ),

            // Play/Pause Button
            const CircleAvatar(
              radius: 35,
              child: AnimatedPlayButton(key: Key("playButton")),
            ),

            // Next
            _nextButton(playerController, context),

            // Loop
            Obx(() => IconButton(
                  onPressed: playerController.toggleLoopMode,
                  icon: Icon(
                    Icons.all_inclusive,
                    color: playerController.isLoopModeEnabled.value
                        ? theme.textTheme.titleLarge!.color
                        : theme.textTheme.titleLarge!.color!.withOpacity(0.2),
                  ),
                )),
          ],
        ),

        const SizedBox(height: 16),
      ],
    );
  }

  Widget _nextButton(PlayerController playerController, BuildContext context) {
    return Obx(() {
      final isLastSong = playerController.currentQueue.isEmpty ||
          (!(playerController.isShuffleModeEnabled.isTrue ||
                  playerController.isQueueLoopModeEnabled.isTrue) &&
              (playerController.currentQueue.last.id ==
                  playerController.currentSong.value?.id));

      return IconButton(
        icon: Icon(
          Icons.skip_next_rounded,
          color: isLastSong
              ? Theme.of(context).textTheme.titleLarge!.color!.withOpacity(0.2)
              : Theme.of(context).textTheme.titleMedium!.color,
          size: 32,
        ),
        onPressed: isLastSong ? null : playerController.next,
      );
    });
  }
}
